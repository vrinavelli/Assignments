﻿using System;
using System.Linq;
using EmployeeApp.BAL;
using EmployeeApp.DTO;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeApp.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly EmployeeManager _manager;

        public EmployeeController()
        {
            _manager = new EmployeeManager();
        }

        // GET: Employee/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Employee/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(EmployeeDTO employee)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _manager.AddEmployee(employee);
                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", ex.Message);
                }
            }
            return View(employee);
        }

        // GET: Employee/Index
        public ActionResult Index()
        {
            var employees = _manager.GetAllEmployees().ToList();
            return View(employees);
        }

        // GET: Employee/Details/5
        public ActionResult Details(int id)
        {
            var employee = _manager.GetEmployeeById(id);
            if (employee == null)
            {
                return View();
            }
            return View(employee);
        }

        // GET: Employee/Edit/5
        public ActionResult Edit(int id)
        {
            var employee = _manager.GetEmployeeById(id);
            if (employee == null)
            {
                return View();
            }
            return View(employee);
        }

        // POST: Employee/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(EmployeeDTO employee)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _manager.UpdateEmployee(employee);
                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", ex.Message);
                }
            }
            return View(employee);
        }

        // GET: Employee/Delete/5
        public ActionResult Delete(int id)
        {
            var employee = _manager.GetEmployeeById(id);
            if (employee == null)
            {
                return View();
            }
            return View(employee);
        }

        // POST: Employee/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            _manager.DeleteEmployee(id);
            return RedirectToAction("Index");
        }
    }
}
