﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EmployeeApp.DTO
{
    public class EmployeeDTO
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required.")]
        [RegularExpression(@"^[a-zA-Z\s]*$", ErrorMessage = "Name can only contain letters and spaces.")]
        [StringLength(100, MinimumLength = 15, ErrorMessage = "Name must be at least 15 characters.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Date of Birth is required.")]
        [Range(typeof(DateTime), "1/1/2002", "12/31/2005", ErrorMessage = "Year of Birth must be between 2002 and 2005.")]
        public DateTime DateOfBirth { get; set; }

        [Required(ErrorMessage = "Date of Joining is required.")]
        [DataType(DataType.Date)]
        [CustomDateOfJoiningValidation]
        public DateTime DateOfJoining { get; set; }

        public decimal? Salary { get; set; }

        [Required(ErrorMessage = "Department is required.")]
        [RegularExpression("^(HR|Accts|IT)$", ErrorMessage = "Department must be HR, Accts or IT.")]
        public string Dept { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }

    // Custom validation for DateOfJoining
    public class CustomDateOfJoiningValidation : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            var dateOfJoining = (DateTime)value;
            return dateOfJoining <= DateTime.Now; // DOJ must be on or before the current date
        }
    }
}
