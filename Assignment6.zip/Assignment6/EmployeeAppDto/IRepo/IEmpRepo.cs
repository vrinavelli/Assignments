﻿using System;
using System.Linq;
using EmployeeApp.DAL;
using EmployeeApp.DTO;

namespace EmployeeApp.BAL
{
    public class EmployeeManager
    {
        private readonly EmployeeRepository _repository;

        public EmployeeManager()
        {
            _repository = new EmployeeRepository();
        }

        public bool IsEmployeeExists(int id)
        {
            return _repository.IsEmployeeExists(id);
        }

        public void AddEmployee(EmployeeDTO employee)
        {
            if (IsEmployeeExists(employee.Id))
            {
                throw new Exception("Employee with the same ID already exists.");
            }

            _repository.AddEmployee(employee);
        }

        public void UpdateEmployee(EmployeeDTO employee)
        {
            if (!IsEmployeeExists(employee.Id))
            {
                throw new Exception("Employee does not exist.");
            }

            _repository.UpdateEmployee(employee);
        }

        public void DeleteEmployee(int id)
        {
            if (!IsEmployeeExists(id))
            {
                throw new Exception("Employee does not exist.");
            }

            _repository.DeleteEmployee(id);
        }

        public EmployeeDTO GetEmployeeById(int id)
        {
            return _repository.GetEmployeeById(id);
        }

        public IQueryable<EmployeeDTO> GetAllEmployees()
        {
            return _repository.GetAllEmployees();
        }
    }
}
