﻿using System;
using System.Linq;
using EmployeeApp.DTO;
using Microsoft.EntityFrameworkCore;

namespace EmployeeApp.DAL
{
    public class EmployeeRepository
    {
        private readonly EmployeeContext _context;

        public EmployeeRepository()
        {
            _context = new EmployeeContext();
        }

        public bool IsEmployeeExists(int id)
        {
            return _context.Employees.Any(e => e.Id == id);
        }

        public void AddEmployee(EmployeeDTO employee)
        {
            _context.Employees.Add(employee);
            _context.SaveChanges();
        }

        public void UpdateEmployee(EmployeeDTO employee)
        {
            _context.Employees.Update(employee);
            _context.SaveChanges();
        }

        public void DeleteEmployee(int id)
        {
            var employee = _context.Employees.Find(id);
            if (employee != null)
            {
                _context.Employees.Remove(employee);
                _context.SaveChanges();
            }
        }

        public EmployeeDTO GetEmployeeById(int id)
        {
            return _context.Employees.Find(id);
        }

        public IQueryable<EmployeeDTO> GetAllEmployees()
        {
            return _context.Employees.AsQueryable();
        }
    }
}
