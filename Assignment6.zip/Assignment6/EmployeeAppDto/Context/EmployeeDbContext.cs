﻿using Microsoft.EntityFrameworkCore;
using EmployeeApp.DTO;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace EmployeeApp.DAL
{
    public class EmployeeContext : DbContext
    {
        public DbSet<EmployeeDTO> Employees { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var builder = WebApplication.CreateBuilder();
            optionsBuilder.UseSqlServer(builder.Configuration["ConnectionStrings:DbConnection"]);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<EmployeeDTO>().HasKey(e => e.Id);
        }
    }
}
