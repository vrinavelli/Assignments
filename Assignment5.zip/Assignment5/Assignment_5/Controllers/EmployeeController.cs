﻿using Assignment_5.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using Assignment_5.Models;

namespace YourAppName.Controllers
{
    public class EmployeeController : Controller
    {
        // Static list to simulate database
        private static List<Employee> employeeList = new List<Employee>();

        // GET: Employee/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Employee/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Employee employee)
        {
            if (ModelState.IsValid)
            {
                // Check if employee ID already exists
                if (employeeList.Any(e => e.ID == employee.ID))
                {
                    ModelState.AddModelError("ID", "ID already exists.");
                    return View(employee);
                }

                // Add employee to the in-memory list
                employeeList.Add(employee);

                return RedirectToAction("Index");
            }

            return View(employee);
        }

        // GET: Employee/Index
        public ActionResult Index()
        {
            return View(employeeList);
        }

        // GET: Employee/Edit/5
        public ActionResult Edit(int id)
        {
            var employee = employeeList.FirstOrDefault(e => e.ID == id);
            if (employee == null)
            {
                ViewBag.ErrorMessage = "Employee not found!";
                return View("Error");
            }
            return View(employee);
        }

        // POST: Employee/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Employee employee)
        {
            if (ModelState.IsValid)
            {
                var existingEmployee = employeeList.FirstOrDefault(e => e.ID == employee.ID);
                if (existingEmployee != null)
                {
                    existingEmployee.Name = employee.Name;
                    existingEmployee.DateOfBirth = employee.DateOfBirth;
                    existingEmployee.DateOfJoining = employee.DateOfJoining;
                    existingEmployee.Salary = employee.Salary;
                    existingEmployee.Dept = employee.Dept;
                    existingEmployee.Password = employee.Password;
                }

                return RedirectToAction("Index");
            }

            return View(employee);
        }

        // GET: Employee/Delete/5
        public ActionResult Delete(int id)
        {
            var employee = employeeList.FirstOrDefault(e => e.ID == id);
            if (employee == null)
            {
                ViewBag.ErrorMessage = "Employee not found!";
                return View("Error");
            }
            return View(employee);
        }

        // POST: Employee/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            var employee = employeeList.FirstOrDefault(e => e.ID == id);
            if (employee != null)
            {
                employeeList.Remove(employee);
            }
            return RedirectToAction("Index");
        }

        // GET: Employee/Details/5
        public ActionResult Details(int id)
        {
            var employee = employeeList.FirstOrDefault(e => e.ID == id);
            if (employee == null)
            {
                ViewBag.ErrorMessage = "Employee not found!";
                return View("Error");
            }
            return View(employee);
        }
    }
}
